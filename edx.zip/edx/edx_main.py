'''
Created on 2017年12月8日

@author: fgj
'''
# coding:utf-8
from edx import edx_downloader, edx_parser, edx_outputer

#from edx import edx_downloader, edx_parser, edx_outputer


class SpiderMain(object):
    def __init__(self):
        #self.urls = url_manager.UrlManager()
        #url管理器，暂时还没用上，那里的代码是用于另一个工程的
        self.download = edx_downloader.HtmlDownloader()
        #下载器
        self.parser = edx_parser.HtmlParser()
        #解析器
        self.outputer = edx_outputer.HtmlOutPuter()
        #输出器

    def craw(self, root_url):
        root_html=self.download.download(root_url)
        #根目录，首页网址
        dirrectory=self.parser.Getdirrectory(root_url,root_html)
        #得到首页分类          
#         self.outputer.output_typehead()
#         for coursetype in dirrectory:
#             coursetype_url=self.parser.getdirrectory_url(root_url,coursetype)
#             coursetype_title=self.parser.getdirrectory_title(coursetype)
#             coursetype_img=self.parser.getdirrectory_img(coursetype)
#             self.outputer.output_type(coursetype_url,coursetype_title,coursetype_img)
        
        #输出分类头
        for coursetype in dirrectory:
            coursetype_url=self.parser.getdirrectory_url(root_url,coursetype)
            course_html=self.download.download(coursetype_url)
            course_data=self.parser.parse(root_url, course_html)
            coursetype_title=self.parser.getdirrectory_title(coursetype)
            print(coursetype)
            for i in range(0,len(course_data['title'])):
                course_data['summary'].extend([None]*(len(course_data['title'])-len(course_data['summary'])))
                print(course_data['title'][i],coursetype_title,course_data['url'][i],
                    course_data['university'][i],course_data['summary'])
            #依次输出课程名，url，大学，教授，简介
            #self.outputer.output_csv(course.get_text(),course_data)
            self.outputer.output_csv(course_data,coursetype_title)
            #输出到csv文件
if __name__ == "__main__":
    root_url = "https://www.edx.org/subjects"
    print(root_url)
    obj_spider = SpiderMain()
    obj_spider.craw(root_url)

