# -*- coding: utf-8 -*-

import csv
import codecs  
#输出到csv,这里花了不少时间，主要是解决utf8编码和输出乱码的问题



class HtmlOutPuter(object):
    def __init__(self):

        csvfile =codecs.open('course_edx.csv', 'w+', 'utf_8_sig') 
        writer = csv.writer(csvfile)       
        writer.writerow([ 'url', 'course_name', 'course_type','course_university','img','summary'])
        csvfile.close()

    
    def output_csv(self,data,coursetype_title):
        for i in range(0,len(data['title'])):
            csvfile =codecs.open('course_edx.csv', 'a+', 'utf_8_sig') 
            writer = csv.writer(csvfile)     
            writer.writerow([data['url'][i],
                             data['title'][i], 
                             coursetype_title,
                             data['university'][i], 
#                              data['processor'],  
                             data['img'][i],
                            data['summary'][i]])


    

    
    
    def output_typehead(self):
        csvfile =codecs.open('coursetype.csv', 'w+', 'utf_8_sig') 
        writer = csv.writer(csvfile)       
        writer.writerow([ 'type_url', 'type_title', 'type_img'])
        
        csvfile.close()
    
    def output_type(self,coursetype_url,coursetype_title,coursetype_img):
        csvfile =codecs.open('coursetype.csv', 'a+', 'utf_8_sig') 
        writer = csv.writer(csvfile) 
        writer.writerow([ coursetype_url, coursetype_title, coursetype_img])
        csvfile.close()

