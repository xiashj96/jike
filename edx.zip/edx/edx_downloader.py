import urllib
from selenium import webdriver
import re

class HtmlDownloader(object):

    def download(self, url):
        if url is None:
            return None
        
        driver = webdriver.PhantomJS()
        #driver.set_page_load_timeout(5)
        driver.maximize_window()
        print(url)
        driver.get(url)
        html=driver.page_source
        driver.quit()
#         user_agent = 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US; rv:1.9.0.7) Gecko/2009021910 Firefox/3.0.7'        
#         headers={'User-Agent':user_agent,} 
#         request = urllib.request.Request(url,None,headers)
#         response = urllib.request.urlopen(request)
#         if response.getcode() != 200:
#             return None
#         res = response.read()  
        return html

    

    
    



    # 四大皆空