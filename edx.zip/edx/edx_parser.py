#!user/bin/env python3  
# -*- coding: gbk -*-

import re
from anaconda_project.plugins.network_util import urlparse

from bs4 import BeautifulSoup
from edx import edx_downloader

class HtmlParser(object):
    def parse(self, url_root, html_con):
        self.download = edx_downloader.HtmlDownloader()
        #������
        
        #�ֱ���ȡ�˿γ�����url����ѧ,����,���,ͼƬ
        course_data={}
        title=[]
        university=[]
        professor=[]
        summary=[]
        url=[]
        img=[]
        
        
        soup = BeautifulSoup(html_con,'html.parser')
        nodes=soup.find('div',class_="js-card-list filtered ").find_all('div',class_="discovery-card course-card shadow verified")
        for node in nodes:
            title.append(node.find('div',class_="title ellipsis-multi-line").find('h3').get_text())
            #title
            university.append(node.find('div',class_="label").get_text())
            #university
            course_url=node.find('a')['href']
            url.append(urlparse.urljoin(url_root, course_url))
            #url
            img.append(node.find('a').find('div',class_="img-wrapper").find('img')['src'])
            #img
            html=self.download.download(course_url)
            soup2=BeautifulSoup(html,'html.parser')
            texts=soup2.find('script',class_="js-schema").get_text()
            try:
                summary.append(texts[texts.index("description")+14:texts.index("subjectOfStudy")-3])
            except ValueError:
                print("no summary")
                summary.append("   ")
            #summary
#             professors=soup2.find('ul',class_="clear-list list-instructors clearfix").find_all('li')
#             ps=" "#���н�ʦ
#             for p in professors:
#                 ps=ps+p.find('p',class_="instructor-name").get_text()+ "   "
#             professor.append(ps)
#             #professor
                
        
        course_data['title']=title
        course_data['img']=img
        course_data['url']=url
        course_data['university']=university
        course_data['professor']=professor
        course_data['summary']=summary    
        
        
        return course_data

    

    
    def Getdirrectory(self,url_root,html_root):
        
        soup = BeautifulSoup(html_root,'html.parser')  
        course_node=soup.find('section',class_="js-subject-cards subject-list-page-cards").find_all('li',class_="subject-card")  
        
        #print(course_node)
        return course_node

    
    def getdirrectory_url(self,url_root,course_node):
        new_url = course_node.find('a')['href']
        #print(link['href'])
        return urlparse.urljoin(url_root, new_url)

    def getdirrectory_title(self,course_node):
        print(course_node.find('span').get_text())
        return course_node.find('span').get_text()

    
    def getdirrectory_img(self,course_node):
        return course_node.find('img')['src']
    
    
    
    
    
    
    


