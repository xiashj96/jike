import csv,codecs 
f = codecs.open('temp.csv', 'w', 'utf_8_sig')  

writer = csv.writer(f)  

writer.writerow(['奥迪','爱迪生','方法'])  
f.close() 