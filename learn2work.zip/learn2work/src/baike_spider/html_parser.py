import re
from anaconda_project.plugins.network_util import urlparse

from bs4 import BeautifulSoup

class HtmlParser(object):
    def parse(self, new_url, html_con):
        #�ֱ���ȡ�˿γ�����url����ѧ,����,���
        course_data={}
        title=[]
        university=[]
        professor=[]
        summary=[]
        url=[]
        soup = BeautifulSoup(html_con,'html.parser', from_encoding='utf-8')
        title_nodes=soup.find_all('h2',class_="coursetitle")
        i=0
        for title_node in title_nodes:
            title.append(title_node.get_text())
            i=i+1
        course_data['title']=title
        
        url_nodes=soup.find_all('div',class_="coursename")
        i=0
        for url_node in url_nodes:
            url_n=url_node.find('a')
            url.append(url_n['href'])
            i=i+1
        course_data['url']=url
        
        information_nodes=soup.find_all('div',class_="fl name")
        i=0
        for information_node in information_nodes:
            uni_pro=information_node.find('li').find_all('span')
            professor.append(uni_pro[0].get_text())
            university.append(uni_pro[1].get_text())  
        course_data['university']=university
        course_data['professor']=professor
        
        summary_nodes=soup.find_all('div', class_="txt_all")
        i=0
        for summary_node in summary_nodes:
            summary_n=summary_node.find('p',class_="txt")
            summary.append(summary_n.get_text());
            i=i+1
        course_data['summary']=summary
        return course_data

    

    
    def Getdirrectory(self,url_root,html_root):
        if url_root is None :
            return
        
        soup = BeautifulSoup(html_root,'html.parser', from_encoding='utf-8')
        

        course_node=soup.find_all('a',href=re.compile(r"http://www.xuetangx.com/courses"))

        #print(course_node)
        return course_node
    
    


