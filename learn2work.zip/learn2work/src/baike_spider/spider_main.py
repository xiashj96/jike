# coding:utf-8

from baike_spider import html_downloader, html_parser, html_outputer, url_manager


class SpiderMain(object):
    def __init__(self):
        self.urls = url_manager.UrlManager()
        #url管理器，暂时还没用上，那里的代码是用于另一个工程的
        self.download = html_downloader.HtmlDownloader()
        #下载器
        self.parser = html_parser.HtmlParser()
        #解析器
        self.outputer = html_outputer.HtmlOutPuter()
        #输出器

    def craw(self, root_url):
        root_html=self.download.download(root_url)
        #根目录，首页网址
        dirrectory=self.parser.Getdirrectory(root_url,root_html)
        #得到首页分类
        for course in dirrectory:
            print(course.get_text())
            #输出课程类
            course_html=self.download.download(course['href'])
            course_data=self.parser.parse(course['href'], course_html)
            for i in range(0,len(course_data['title'])):
                print(course_data['title'][i],course_data['url'][i],
                      course_data['university'][i],course_data['professor'][i],
                      '\n',course_data['summary'][i])
            #依次输出课程名，url，大学，教授，简介
            self.outputer.output_csv(course.get_text(),course_data)
            #输出到csv文件
if __name__ == "__main__":
    root_url = "http://www.xuetangx.com/"
    obj_spider = SpiderMain()
    obj_spider.craw(root_url)

