# -*- coding: utf-8 -*-

import csv
import codecs  
#输出到csv,这里花了不少时间，主要是解决utf8编码和输出乱码的问题



class HtmlOutPuter(object):
    def __init__(self):

        csvfile =codecs.open('course.csv', 'w+', 'utf_8_sig') 
        writer = csv.writer(csvfile)       
        writer.writerow(['coursetype', 'url', 'course_name', 'course_university', 'course_professor','course_summary'])
        csvfile.close()

    def collect_data(self, new_data):
        if new_data is None:
            return
        self.datas.append(new_data)

    
    def output_csv(self,text,data):
        
        for i in range(0,len(data['title'])):
            csvfile =codecs.open('course.csv', 'a+', 'utf_8_sig') 
            writer = csv.writer(csvfile)       
            writer.writerow([text, data['url'][i],
                             data['title'][i], 
                             data['university'][i], 
                             data['professor'][i],
                             data['summary'][i] ])


